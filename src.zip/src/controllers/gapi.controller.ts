import { Request, Response } from 'express';
import { defineSecret, defineString } from 'firebase-functions/params';
import { logger } from 'firebase-functions/v2';
import { onRequest } from 'firebase-functions/v2/https';
import { google } from 'googleapis';

import { enterpriseDb } from '../modules';

/* -----------------------------
   Params + Secrets
----------------------------- */

const GOOGLE_CLIENT_ID = defineString('MAS_GOOGLE_CLIENT_ID');
const GOOGLE_REDIRECT_URI = defineString('MAS_GOOGLE_REDIRECT_URI');
const GOOGLE_SCOPES = defineString('MAS_GOOGLE_SCOPES');

const MAS_GOOGLE_CLIENT = defineSecret('MAS_GOOGLE_CLIENT');

/* -----------------------------
   Helpers
----------------------------- */

const debugLog = (message: string, data?: any): void => {
	if (process.env.FUNCTIONS_EMULATOR) {
		logger.log(`${message}=${data ? JSON.stringify(data, null, 2) : ''}`);
	}
};

const createOAuth2Client = (): any => {
	const redirect = process.env.FUNCTIONS_EMULATOR ? `http://127.0.0.1:5001/${process.env.GCLOUD_PROJECT}/us-central1/gapi/oAuthCallback` : GOOGLE_REDIRECT_URI.value();

	return new google.auth.OAuth2(GOOGLE_CLIENT_ID.value(), MAS_GOOGLE_CLIENT.value(), redirect);
};

/* -----------------------------
   OAuth Login URL
----------------------------- */

export const googleLogin = onRequest({ secrets: [MAS_GOOGLE_CLIENT] }, (request: Request, response: Response) => {
	try {
		const scopes = GOOGLE_SCOPES.value().split(' ');

		const oAuth2Client = createOAuth2Client();

		const authUrl = oAuth2Client.generateAuthUrl({
			access_type: 'offline',
			scope: scopes,
			prompt: 'consent',
		});

		debugLog('authUrl', authUrl);

		response.status(200).send({ authUrl });
	} catch (e) {
		logger.error('Error in googleLogin:', e);
		response.status(500).send({ error: 'Failed to generate login URL' });
	}
});

/* -----------------------------
   Access Token Refresh
----------------------------- */

export const accessToken = onRequest({ secrets: [MAS_GOOGLE_CLIENT] }, async (request: Request, response: Response) => {
	const gapirefreshtoken = request.headers.gapirefreshtoken as string;

	if (!gapirefreshtoken) {
		response.status(400).send({ error: 'Missing gapirefreshtoken header' });
		return;
	}

	try {
		const oAuth2Client = createOAuth2Client();
		oAuth2Client.setCredentials({ refresh_token: gapirefreshtoken });

		const { token } = await oAuth2Client.getAccessToken();

		if (!token) {
			throw new Error('Failed to retrieve access token');
		}

		response.status(200).send({ token });
	} catch (e) {
		logger.error('Error getting accessToken:', e);
		response.status(500).send({ error: 'Failed to get accessToken' });
	}
});

/* -----------------------------
   OAuth Callback
----------------------------- */

export const oAuthCallback = onRequest({ secrets: [MAS_GOOGLE_CLIENT] }, async (request: Request, response: Response) => {
	const { error, code } = request.query as {
		error?: string;
		code?: string;
	};

	if (error) {
		response.status(400).send({ error: `OAuth error: ${error}` });
		return;
	}

	if (!code) {
		response.status(400).send({ error: 'Missing authorization code' });
		return;
	}

	try {
		const oAuth2Client = createOAuth2Client();
		const { tokens } = await oAuth2Client.getToken(code);

		// ✅ ENTERPRISE DATABASE WRITE
		await enterpriseDb.collection('oauthTokens').add(tokens);

		response.send('OAuth Success. Token saved in Enterprise DB.');
	} catch (e) {
		logger.error('OAuth callback failed:', e);
		response.status(500).send({ error: 'OAuth callback failed' });
	}
});
